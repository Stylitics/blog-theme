$(window).load(function() {
	$('.flexslider').flexslider({
		controlNav: false
	});
});

