=== Tumblr Export for WordPress ===
Contributors: nquinlan
Tags: export, move, tumblr
Requires at least: 2.5
Tested up to: 3.0.2
Stable tag: 0.5

Export your WordPress blog to Tumblr.

== Description ==

Easily export your WordPress blog to a Tumblr blog.

== Installation ==

1. Upload `tumblr-export-for-wordpress` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Under the 'Tools' menu, select 'Export to Tumblr'

== Frequently Asked Questions ==

= What will be exported? =

**Just** the text of your blogposts, currently shortcodes and images are not exported, although, eventually they may be.

== Screenshots ==

1. The export screen.

== Changelog ==

= 0.5 =
* Initial Plugin.

== Upgrade Notice ==

= 0.5 =
The first version.

== Known Issues ==

* Images are not exported
* Shortcodes are not processed