=== Mechanic Post by Category ===

Contributors: adityasubawa
Donate link: http://www.adityawebs.com
Tags: post by category, summary post, summary post category, article post category
Requires at least: 3.0.1
Tested up to: 3.4.1
Stable tag: 1.0

Mechanic post by category is widget to display summary post or aticle sort by category. Easy to use, install, setup and come with several options to control how it looks on your wordpress website.

== Description ==

Mechanic post by category is widget to display summary post or aticle sort by category. Easy to use, install, setup and come with several options to control how it looks on your wordpress website. Display the most recent posts from a certain category. some Feature is Summary post, title post, and number of post to display in to sidebar or footer. 
You can make a lot of post widgets to each category. and displays them based on the category that you choose.


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `postbycatmechanic.zip` to the `/wp-content/plugins/` directory. You can do this using 'Upload' functionality provided in plugins section of your wordpress dashboard
2. Activate the plugin through the `Plugins` menu in WordPress
3. Go to `Appearance` >> `Widgets` and drag `Mechanic - Post By Category` in to your WordPress sidebar or footer.
4. Save
5. You are done. 

== Screenshots ==

1. Widget Configuration

== Frequently Asked Questions ==

= How to define the length of summary? =

* for a while, widgets are only equipped with simple settings. wait for further development and you can ask directly to our support services..

== Changelog ==

= 1.0 =

Plug-in is now compatible upto wordpress version 3.4.

== Credits ==

[Aditya Subawa](http://www.adityawebs.com/) - This plugin was created by Aditya Subawa. If you like this widget and would like to donate to help support new versions of this widget you can do so at the <a href="http://www.adityawebs.com">support center</a> website.

== Contact ==

If you need help, support or would just like to provide your comments and suggestions you may visit us online at <a href="http://balimechanicweb.net">our website</a> or <a href="http://www.adityawebs.com">my personal website</a> support center.