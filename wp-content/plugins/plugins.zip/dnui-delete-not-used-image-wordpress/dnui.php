<?php
/*
  Plugin Name: DNUI (Delete not used images)
  Version: 0.8.2
  Plugin URI: http://www.nicearma.com/delete-not-used-image-wordpress-dnui/
  Author: Nicearma
  Author URI: http://www.nicearma.com/
  Description: This plugin will delete all not used images file, the plugin search all image, not referred by any post and page of wordpress
 */

/*
  Copyright (c) 2012 http://www.nicearma.com but this plugin is based in DUI http://www.bobhobby.com/2008/02/24/delete-unused-image-files-plugin-for-wordpress/
  Released under the GPL license
  http://www.gnu.org/licenses/gpl.txt
 */

### Load WP-Config File If This File Is Called Directly
if (!function_exists('add_action')) {
    require_once('../../../wp-config.php');
}

//  Check in the database if the image is used in post_content
function DNUI_checkImageDB($ImageName) {
    global $wpdb, $table_prefix;
    $sql = "SELECT COUNT(*) FROM " . $table_prefix . "posts  WHERE post_content LIKE '%/$ImageName%'";
 
    $result = $wpdb->get_results($sql, "ARRAY_A");
    return $result[0]['COUNT(*)'] > 0;
}

//check all image in database who have the condition Type of post 'attachment'  Type of MIME = 'image'and give all the sizes 
function DNUI_getImages($i, $max,$order=0) {
    global $wpdb, $table_prefix;
    
    $sql = 'SELECT id,meta_id, meta_value FROM ' . $table_prefix . 'posts, ' . $table_prefix . "postmeta where post_type='attachment' and post_mime_type like  'image%' and " . $table_prefix . "posts.id=" . $table_prefix . "postmeta.post_id and " . $table_prefix . 'postmeta.meta_key=\'_wp_attachment_metadata\' ';
    $last= ' ORDER BY  `' . $table_prefix . 'postmeta`.`meta_id`';
    if($order==0){
        $last.=' ASC ';
       
    }else{
         $last.=' DESC ';
    }
    $sql.=$last .' LIMIT ' . ($i * $max) . ", $max";
    return $wpdb->get_results($sql, "ARRAY_A");
}

//Make update of wp_postmeta with a vector sizes serialized the one image 
function DNUI_updateImages($value, $id) {
    global $wpdb, $table_prefix;
    $value = str_replace("'", "''", $value);
    $sql = 'update ' . $table_prefix . "postmeta set meta_value='" . ($value) . "' where meta_id='$id'";
    return $wpdb->query($sql);
}

/*
 * Use for see all the image in the databe
 * $i = Point for the query 
 * $max = limit for the database query, this is because if you have a big site and you not have this, your site will overload
 * $used = Number of image used
 * $notused = Number of image used
 */

function DNUI_allImage($i, $max=50) {
   
    //Get all the image from the data base
    $res = DNUI_getImages($i, $max,$_SESSION['DNUI']['order']);
    
    $used = 0;
    $notused = 0;
    if (!empty($res)) {
        foreach ($res as $key => $unser) {
            //the result of meta_value is serialized 
            $seri = unserialize($unser['meta_value']);
            //get the id of the attachment image
            $id = $unser['id'];
            //get the original image
            $name = $seri['file'];
            //save the original vector of meta_value, for use after in delete_image
            $original[$id] = $seri;
            $files[$id]['father'][] = $name;
            $files[$id]['meta_id'][] = $unser['meta_id'];
            //check the name of one single file, if the father is used
            if (DNUI_checkImageDB(array_pop(explode('/', $name)))) {
                $files[$id]['father']['existe'] = true;
                $used++;
            } else {
                $files[$id]['father']['existe'] = false;
                $notused++;
            }
            //if the original file have some copy of the diferent sizes
            if (!empty($seri['sizes'])) {
                //$key represent the name of the copy in the database Example 'Large'
                foreach ($seri['sizes'] as $keyu => $sizes) {
                    //the name in the server from this copy
                    $name = $sizes['file'];
                    $files[$id]['son'][$keyu][] = $sizes['file'];

                    if (DNUI_checkImageDB($name)) {
                        $used++;
                        $files[$id]['son'][$keyu]['existe'] = true;
                    } else {
                        $files[$id]['son'][$keyu]['existe'] = false;
                        $notused++;
                    }
                }
            }
        }
    }
    //all the session is for used later, but only $_SESSION['DNUI']['original'] is for DNUI_delete
    $_SESSION['DNUI']['original'] = $original;
    $_SESSION['DNUI']['used'] = $used;
    $_SESSION['DNUI']['notused'] = $notused;
    return $files;
}

//-----------------------------------------------------------------------------------
// add management in option menu 
function add_DNUI_option_menu() {
    if (function_exists('add_options_page')) { // is this check needed?
        add_options_page('DNUI option', 'DNUI', 8, basename(__FILE__), 'DNUI_options');
    }
}

function DNUI_delete() {
    //if send to delete something
    if (!empty($_POST['im'])) {
        $im = $_POST['im'];
        //verify is session have something to, if null, this plugin have problem with session 
        if (!empty($_SESSION['DNUI']['original'])) {
            foreach ($im as $key => $value) {
                //Basura = trash, this is only for take information from the $_post
                $basura = explode(':::', $value);
                //type = if father (the original file) or sons(copys of the same file)
                $type = $basura[0];
                //id of the father (the original file)
                $id = $basura[1];

                //only if change to another father, is because of i used the same vector for do the work, and delete for example the copy Large
                if ($old != $id) {
                    $original = $_SESSION['DNUI']['original'][$id];
                    $new = $original;
                    $old = $id;
                }
                //if the file is a copy
                if ($type != 'father') {
                    //take the root of the file in the server  
                    $file = $basura[3];
                    //take only the name
                    $name = array_pop(explode('/', $file));
                    //unset for example Large from the vector
                    unset($new["sizes"][$type]);
                    //try to make the update of the database
                    if (DNUI_updateImages(serialize($new), $basura[2]) !== false) {
                        //try to delete the file
                        if (@unlink($file)) {
                            echo $name . '---> ' . $file . ' <font color="#FF0000">Deleted</font><br>';
                        } else if (file_exists($file)) {
                            //if can't delete the file, return to the old information to the database
                            DNUI_updateImages(serialize($original), $basura[2]);
                            echo $name . '---> ' . $file . ' <font color="#FF0000">Cannot delete file.Please change directory premissions to <font color="#000000">777</font></font><br>';
                        } else {
                            //the file not exist
                            echo $name . '---> ' . $file . ' <font color="#FF0000">This file appears not exist, that is why the plugin update the database</font><br>';
                        }
                    }
                } else {
                    $file = $basura[2];
                    $name = array_pop(explode('/', $file));
                    //for the momento this not work, is for delete the father to
                    wp_delete_attachment($id);
                    echo $name . '---><font color="#FF0000"> Attachment number :' . $id . ' Deleted</font><br>';
                }
                echo '<hr>';
            }
        } else {
            echo "<p><font color='#FF0000'>Error session empty</font> : Sorry but you this plugin have problem with session,</p>";
        }
    }
}

function DNUI_logic() {
           if (empty($_SESSION['DNUI']['i'])) {
               $i = 0;
           } else {
               $i = $_SESSION['DNUI']['i'];
           }

    //this help to go to another 50 files
    if (!empty($_POST['Delete'])) {
        //only if the button is Delete, this plugin will delete
        DNUI_delete();
    } elseif (!empty($_POST['Next'])) {
        $i++;
    } elseif (!empty($_POST['Before'])) {
        if (!$i < 1) {
            $i--;
        }
    }
    $_SESSION['DNUI']['i'] = $i;


    $image = DNUI_allImage($i, $_SESSION['DNUI']['query']);
    //get the upload dir of your configuration
    $uploads = wp_upload_dir();
    $newdir = $uploads['basedir'];
    $urldir = $uploads['baseurl'];

    //print the number of image total, used and not used
    echo "<br><b>There are total <font color='#0000FF'>" . ($_SESSION["DNUI"]["used"] + $_SESSION["DNUI"]["notused"]) . "</font> images found</b><br><br>";
    echo "<b>There are total <font color='#00FF00'>" . $_SESSION["DNUI"]["used"] . "</font> images used</b><br><br>";
    echo "<b>There are total <font color='#FF0000'>" . $_SESSION["DNUI"]["notused"] . "</font> not used images</b><br><br>";

    DNUI_button();
    if (!empty($image)) {
        foreach ($image as $key => $file) {
            $delAll = true;
            $html = "";
            if (!empty($file["father"])) {
                $father = explode("/", $file["father"][0]);
                $name = array_pop($father);
                $folder = implode("/", $father);
                $html.= '<input type="checkbox" ';
                if ($file["father"]['existe'])
                    $delAll = false;
                $html2 = "";
                if (!empty($file["son"])) {
                    $meta_id = $file["meta_id"][0];
                    $html2 = '<ol>';

                    foreach ($file["son"] as $keyu => $son) {
                        $html2.= '<li><input style="display:inline;" type="checkbox"';
                        if ($son['existe']) {
                            $delAll = false;
                            $html2.= ' disabled ';
                        }

                        $html2.= 'name="im[]" id="son_'.$key.'" value="' . "$keyu:::$key:::$meta_id:::$newdir/$folder/$son[0]" . '"/>' . $son[0] . '&nbsp;&nbsp;&nbsp;&nbsp;<a href="' . "$urldir/$folder/$son[0] " . '" target="_blank">View</a><br> </li>';
                    }

                    $html2.= '</ol>';
                }
                if (!$delAll){
                    $html.= ' disabled ';
                }else{
                    $html.="onclick=\"dnui('$key')\"";
                }
                $html.= 'name="im[]" id="'.$key.'" value="father:::' . $key . ':::' . $newdir . "/" . $file["father"][0] . '"/>' . $name . '&nbsp;&nbsp;&nbsp;&nbsp;<a href="' . $urldir . "/" . $file["father"][0] . '" target="_blank">View</a><br>';
                $html.=$html2;
            }
            echo $html;
        }
        echo '<hr>';
        ?> 
<input type="button" onclick="dnui_all(true)" value="Select All"  />
<input type="button" onclick="dnui_all(false)" value="unselect All"  />
        <input type="submit" name="Delete" value="Delete"  />
    <?php
    }
    DNUI_button();
}

function DNUI_button() {
    ?>
        <br>
    <input type="submit" name="Before" value="Before" 
    <?php
    if ($_SESSION['DNUI']['i'] == 0)
        echo ' disabled ';
    ?>
           class="button" />
    <input type="submit" name="Next" value="Next"
    <?php
    if (($_SESSION["DNUI"]["used"] + $_SESSION["DNUI"]["notused"]) == 0)
        echo ' disabled ';
    ?>
           class="button"  /><br>
           <?php
       }

// main option -----------
function DNUI_options() {
   
                if ((!empty($_POST['query'])) && (is_numeric($_POST['query']))) {
               $_SESSION['DNUI']['query'] = $_POST['query'];
               $makeScan = true;
           } else {
               $_SESSION['DNUI']['query'] = 25;
           }
$_SESSION['DNUI']['order']=0;
 if(!empty ($_POST['order'])&&is_numeric($_POST['order'])){
        $_SESSION['DNUI']['order']=$_POST['order'];
    }
           ?>
    <div class="wrap">
        <h2>Delete Not Used Images</h2>
        <form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>"> 
            Number of query(Father)  <input type="text" name="query" value="<?php echo $_SESSION['DNUI']['query'] ?>"><input type="submit" name="change" value="Make scan"  /><br>
           
            
            Order By <select name="order"><option <?php if($_SESSION['DNUI']['order']==0) echo "selected" ?> value="0">First</option><option  <?php if($_SESSION['DNUI']['order']==1) echo "selected" ?> value="1">Last</option></select>
                

             <?php
            if ($makeScan)
                DNUI_logic();
            ?>
        </form>
        <a href="http://www.nicearma.com/delete-not-used-image-wordpress-dnui/" target="_blank">Page of the plugin</a>
    </div>     
    <script type="text/javascript">
function dnui(id){
    a=document.getElementsByName('im[]');
    if(document.getElementById(id).checked){
    for(i=0;i<a.length;i++){
        if(a[i].id=="son_"+id){
            a[i].checked=false;
            a[i].disabled=true;
        }
    }
    }else{
    for(i=0;i<a.length;i++){
        if(a[i].id=="son_"+id){
             a[i].disabled=false;
        }
    }
    }
}

function dnui_all(state){
    a=document.getElementsByName('im[]');
    for(i=0;i<a.length;i++){
        if((a[i].id.match("son"))&&!(a[i].disabled)){
            a[i].checked=state;
        }
    }
}
</script>
    <?php
}

add_action('init', 'session_start');
add_action('admin_menu', 'add_DNUI_option_menu');
?>