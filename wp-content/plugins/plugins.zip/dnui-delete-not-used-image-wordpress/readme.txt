=== DNUI Delete not used image===
Contributors: nicearma
Donate link: http://www.nicearma.com/
Tags: image,images, delete, image not used, image unused, delete unused image, delete not used image
Requires at least: 3.0 
Tested up to: 3.3
Stable tag: trunk

Delete and update not used image and database

== Description ==

(Please give me some feedback, recommendation, comments because i don't know if all work fine or you want something more)

DNUI will help you to identify all image not used in your wordpress post and page, and give you the option to delete them, this will delete the image from the server and update the database so that the image is no longer shown when making a post, because the problem of wordpress is, if you upload one image, wordpress can make 4 image from the same file, so this plugin help you to identify all them and delete the image what you want.

This plugin make a scan of your database and find all the files you never used in a post, for defaul you are going to scan 25 files for each time(please be careful if you change this number, a big number going to take down the server),for example you are going to see 25 files parents(the original image) and maybe for every parent 4 sons(the image made aaaxbbb)

Please make sure before you use this plugin see the tutorial at [Tutorial DNUI](http://www.nicearma.com/delete-not-used-image-wordpress-dnui/)

[Tutorial en español](http://www.nicearma.com/dnui-borrar-imagenes-no-utilizadas-en-wordpress/)

The search code uses the rule that the post should be referred to the desired image, so if nicearma.jpg image is not on any post, this picture is taken as not used, so the plugin will allow you to delete the image, otherwise it will not let you delete the image, since the box will be disabled.

Note: If your wordpress site does not use this rule you might see pictures with the option to erase, therefore follows the recommendation 2

Note:For the moment you only can choose the sons if this image was not used in older post (i'm working on the option of delete the fathers to)

** New : Now you can delete the father to, this plugin use the fuction  wp_delete_attachment for that task**

Recommendations(practically obligatory)

* Make a save (Backup) of your database and your file (especially the uploadsfolder), because the code have to update the database and deletion of files that are irreversible,so if something goes wrong is better have a backup.
* Performs tests on any page other than your own default, but having the same characteristics, since I have not tested for compatibility with other plugin, so you can see if will work fine
* Download this plugin only wordpress.org.


== Installation ==

1. Upload the `DNUI` folder to your `/wp-content/plugins/` directory
2. Activate the plugin using the `Plugins` menu in WordPress


== Frequently Asked Questions ==

= Why you have to make a backup  =

I have only tested in two site and with only the native uploader, so i dont know what going to happen if you have some other plugin, or maybe you are going to have issues because this a new plugin and maybe miss something important 

== Screenshots ==

1. You are going to see all the image in your data base, but only 25 parents(the file upload) and maybe the sons(if they have, the version aaaXbbb of the image)
2. For the moment you only can delete children who are not in any post
3. You choose the file and send Delete
4. The image was deleted from the server and the fild in database updated

== Changelog ==
= 0.8.2 =
* Fix bug multisite compatibility

= 0.8.1 =
* Add select all (only son)
* Add unselect all (only son)
= 0.8 =
* Add Order old

= 0.7 =
* Add delete of the fahter
* Add javascript
* Add update of the databe if the file not exist
* Add change max of the query

= 0.6.1 =
* Add session_start to init

= 0.6 =
* Add verification of sessions
* Add security in the delete

== Upgrade Notice ==
