=== Plugin Name ===
Contributors: sudiptomahato
Donate link: http://techxt.com/donate
Tags: Simple social share, social share, Facebook, Like, google, google +1, google plusone, twitter, tweet, facebook share, plusone, linkedin
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 1.6

A very simple social share plugin with just 5 social icons (Twitter, FB Like, Google +1, Linkedin and FB Share) 

== Description ==
A very simple social share plugin with just 5 social icons. Well the around 99% of the posts are share with these 5 social icons (i.e Twitter, FB Like, Google +1, Linkedin and FB Share) then why to have more. Lesser social icons means less load on pages and you pages will load much faster. Earlier there were just 4 icons. But upon the request of many of this plugin user I decided to add the Linkedin button.

Features of the plugin

*   Huge list of options to easily display the buttons where require
*   Support for `shortcode` to display anywhere inside your post/page
*   Display using function call (useful if you want to embeb the code directly to your theme)

Facebook no longer supports the Share button so I had to remove the button. Well there is still a way to display the Share button. [Have a look at this post](http://techxt.com/plugin-support-forum/tweet-like-plusone-and-share-plugin/display-facebook-share-button-custom-button/)

How to use the Shortcode and the Function to display the buttons
[Reference on using the shortcode and the function](http://techxt.com/tweet-like-google-1-and-share-plugin-wordpress/)
 
Check out the options page of the plugin by clicking on the link below
[Click here for Screenshots and options available with this plugin](http://techxt.com/tweet-like-google-1-and-share-plugin-wordpress/)


Your suggestion is always appreciated.
[Comment on this page ](http://techxt.com/tweet-like-google-1-and-share-plugin-wordpress/) to suggest a feature or to report a bug.

[Author's site](http://techxt.com/)

== Installation ==

1. Upload `only-tweet-like-share-and-google-1` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Goto the Settings > Tweet Like Plusone to change setting


== Screenshots ==

For screenshots goto this page http://techxt.com/tweet-like-google-1-and-share-plugin-wordpress/

