=== xTechnos Online Poll ===
Contributors: zagham.naseem
Tags: online poll, xtechnos poll, wordpress poll, wp poll, poll widget, poll with short code, poll page
Requires at least: 3.0
Tested up to: 3.3.2
Stable tag: 2.1.0

xTechnos Online Poll.


== Description ==

xTechnos Online Poll is a wordpress online poll, you can use poll widget or place poll in any page/post using short code, very easy to use, you can add new poll from admin panel and check results.

= Plugin's Official Site =

xTechnos Online Poll ([http://xtechnos.com](http://xtechnos.com/))

= Features =
* Add Poll as Post
* Support Multiple Polls
* Show poll in widget.
* Show poll in posts/pages.
* Realtime answer checking.
* View results in Graph format.
* Save results in database.
* Download results in image format.

== Installation ==

1. Upload the plugin to your 'wp-content/plugins' directory
2. Activate the plugin
3. You can use [xTechnos-Online-Poll] short code to place poll in any page/post
4. You can use xTechnos Online Poll widget in sidebar

== Frequently Asked Questions ==


== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png
4. screenshot-4.png
5. screenshot-5.png

== Changelog ==

= 2.0.3 =
* 3d Charts Added

= 2.0.3 =
* Banner Added :)

= 2.0.2 =
* Result Table is Added
* Some Bugs Fixed

= 2.0.0 =
* Bug Fixed
* Add Post type feature
* Add Polls as post
* Edit/Delete Polls
* Support Multiple Polls
* Show results as pie graph format
* Download results

= 1.0.0 =
* Bug Fixed
* Add Result Feature

= 0.1.0 =
* Initial release version
