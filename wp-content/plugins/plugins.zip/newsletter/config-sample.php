<?php
/*
 * Move this file inside the /wp_content/newsletter folder to activate it and rename it
 * "config.php".
 * 
 */

// Even if still called "list" those are the user's "preferences"
// define('NEWSLETTER_LIST_MAX', 20);
// define('NEWSLETTER_PROFILE_MAX', 20);
// define('NEWSLETTER_FORMS_MAX', 10);
?>