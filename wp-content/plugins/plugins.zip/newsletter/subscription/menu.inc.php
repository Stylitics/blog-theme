<h2>Subscription</h2>
<div id="newsletter-nav">
    <a class="button" href="?page=newsletter/subscription/options.php">Subscription and unsubscription</a>
    <a class="button" href="?page=newsletter/subscription/profile.php">Form fields and layout</a>
    <!--<a class="button" href="?page=newsletter/subscription/form-code.php">The form code</a>-->
    <a class="button" href="?page=newsletter/subscription/forms.php">Other forms</a>
</div>