Blank newsletter!

---
To unsubscribe follow the link
{unsubscription_url}
to edit your profile follow the link
{profile_url}