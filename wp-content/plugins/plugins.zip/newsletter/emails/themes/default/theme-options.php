<table class="form-table">
    <tr>
        <th>Base color</th>
        <td><?php $controls->color('theme_color'); ?></td>
    </tr>
    <tr>
        <th>Add latest posts</th>
        <td><?php $controls->checkbox('theme_posts'); ?></td>
    </tr>
</table>