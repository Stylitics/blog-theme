<h2>Subscribers Module</h2>

<div id="newsletter-nav">
    <a class="button" href="?page=newsletter/users/index.php">Search and edit</a>
    <a class="button" href="?page=newsletter/users/new.php">New subscriber</a>
    <a class="button" href="?page=newsletter/users/massive.php">Massive changes</a>
    <a class="button" href="?page=newsletter/users/stats.php">Statistics</a>
    <a class="button" href="?page=newsletter/users/import.php">Import</a>
    <a class="button" href="?page=newsletter/users/export.php">Export</a>
</div>